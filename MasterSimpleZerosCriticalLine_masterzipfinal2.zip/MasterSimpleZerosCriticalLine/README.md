# More than 67.32 percent of the zeta zeros are simple and on the critical line

Deep Bhattacharjee (ORCID 0000-0003-0466-750X; itsdeep@live.com, d.bhattacharjee@erl-forschung.de)
and Ushashi Bhattacharya (ORCID 0009-0002-2254-3914).

- `SimpleZerosCriticalLine.pdf`: the paper.
- `hexagon/`: the Hexagon submission package (PDF, TeX zip compiled with pdflatex -jobname=output on TeX Live 2026, arXiv tarball, AI provenance, form).
- `source/`: the repository creelie/mh-phys: LaTeX source, the branch-and-bound verifiers with their certified logs and the weights, the kernel tables, the checks, the linear programmes, notes and workflows. See `source/README.md` for how to repeat the certificate.

Result (release 1.2.0): liminf N₀ˢ(T,2T)/N(T,2T) ≥ (1000/993)(H − 19999/5000000) = 0.6732133974…, with H the Montgomery–Taylor constant, from a weighted inequality for nine consecutive zeros (52,891,178,741 branch-and-bound nodes). Earlier releases gave 0.6731985970 (1.1.0, weighted eight-zero windows) and 0.6731133552 (1.0.0, uniform weights). This is not a proof of the Riemann hypothesis.
