# AI provenance: More Than 67.32 Percent of the Zeta Zeros Are Simple and on the Critical Line

Authors: Deep Bhattacharjee (corresponding author, ORCID 0000-0003-0466-750X)
and Ushashi Bhattacharya (ORCID 0009-0002-2254-3914).

- Paper: https://github.com/creelie/mh-phys/blob/main/preprintSimpleZerosCriticalLine/SimpleZerosCriticalLine.pdf
- Repository: https://github.com/creelie/mh-phys
- Archive: release 1.3.0, doi:10.5281/zenodo.23489033

## Result

At least 0.6732896395 of the nontrivial zeros of ζ (counted with multiplicity)
are simple and lie on the critical line, in the sense of the lower density
liminf N₀ˢ(T,2T)/N(T,2T) ≥ (125000/124111)(H − 7999/2000000), with H the
Montgomery–Taylor constant 0.6725007. The previous bounds were 0.6725007
(Alpöge–Furman, Lamzouri), 0.6730085 (creelie/zeta-simple-zeros), 0.6731134
(release 1.0.0 of creelie/mh-phys, uniform weights), 0.6731986 (release
1.1.0, weighted eight-zero windows) and 0.6732134 (release 1.2.0, weighted
nine-zero windows). The paper also shows that no weights for ten zeros give
more than 0.6732908 and that no window length or weights lift
the method above 0.6736.

## Who did what

Deep Bhattacharjee chose the problem, directed the work, set the format, and
ran the computations. Claude (Anthropic), used through Claude Code under his
direction, produced the eigenvalue lemma and its proof, the block
decomposition, the weighted window lemma, the linear programme that chooses the
weights, the verification programs, the figures and the LaTeX text. The
search was organised by the learn-from-failure protocol of the BLLM engine
Anaxia (creelie/eBLLM, release 3.1.1, doi:10.5281/zenodo.23484395): eight failed rounds, each recorded with
the rule it teaches, led to the uncapped defect and the eigenvalue bound; before the ten-zero
round, and again before the second-order checker, the engine's main branch
was read for new construction techniques (to its pull request 33: gadget
graphs, CEGAR forcers, the tensor engine, the barrier ledger and atlas, the
superstring and blow-up modules); they address Hodge, strings and
Yang–Mills, and none acts on zero windows. No
other AI system took part. The rank–trace framework is due to Alpöge and
Furman and is cited.

## How the result is checked

- The eigenvalue lemma, the stability lemma, the pinching step and the block
  accounting are proved by hand in the paper.
- The window inequality F ≥ 889/125000 = 0.007112 for ten consecutive zeros,
  with the weights of Table I (rational, rounded down and up), is verified by
  branch and bound with two lower bounds on each box: one from a table of
  lower bounds for w = k² on cells of width 1/4000, and a second-order Taylor
  bound from tables of w and w′ at the grid points and of lower bounds for w″
  on cells, all computed in 128-bit ball arithmetic (python-flint/Arb). The C
  search runs with rounding toward minus infinity throughout; upper bounds are
  formed as −((−x)·y). 1,424,333,714 nodes in under three minutes on four
  threads, VERIFIED. The minimum of F for these weights is 0.00711257, and
  the target 0.0071125 fails at a single cell. The nine-zero inequality
  F ≥ 7/1000 of release 1.2.0 (52,891,178,741 nodes) and the eight-zero
  inequality F ≥ 19/4000 of release 1.1.0 (21,067,790,614 nodes) were
  verified the same way. The weights were found by a linear programme in floating point;
  no proof rests on how they were found.
- With uniform weights the same kind of search verified F₈ ≥ 13/3125 at
  μ₀ = 1/3200 (10,039,560,518 nodes) and, with an independent serial program,
  the inequality at μ₀ = 1/2000.
- The kernel values, the majorant inequality and the lattice eigenvalues are
  rechecked in ball and floating-point arithmetic.

## What is not claimed

The paper does not prove the Riemann hypothesis and does not bear on it: a
bound of this kind is insensitive to a set of zeros of density zero. The
argument uses the framework of the arXiv preprint of Alpöge and Furman, which
is not yet refereed.
