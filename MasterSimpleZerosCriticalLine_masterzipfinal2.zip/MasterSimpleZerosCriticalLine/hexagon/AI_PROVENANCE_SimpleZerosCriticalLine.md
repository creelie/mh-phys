# AI provenance: More Than 67.31 Percent of the Zeta Zeros Are Simple and on the Critical Line

Authors: Deep Bhattacharjee (corresponding author, ORCID 0000-0003-0466-750X)
and Ushashi Bhattacharya (ORCID 0009-0002-2254-3914).

- Paper: https://github.com/creelie/mh-phys/blob/main/preprintSimpleZerosCriticalLine/SimpleZerosCriticalLine.pdf
- Repository: https://github.com/creelie/mh-phys

## Result

At least 0.6731133552 of the nontrivial zeros of ζ (counted with multiplicity)
are simple and lie on the critical line, in the sense of the lower density
liminf N₀ˢ(T,2T)/N(T,2T) ≥ (3125/3112)(H − 7/3200), with H the
Montgomery–Taylor constant 0.6725007. The previous bounds were 0.6725007
(Alpöge–Furman, Lamzouri) and 0.6730085 (creelie/zeta-simple-zeros). The paper
also shows that no window length lifts the method above 0.6736.

## Who did what

Deep Bhattacharjee chose the problem, directed the work, set the format, and
ran the computations. Claude (Anthropic), used through Claude Code under his
direction, produced the eigenvalue lemma and its proof, the block
decomposition, the verification programs, the figures and the LaTeX text. The
search was organised by the learn-from-failure protocol of the BLLM engine
Anaxia (creelie/eBLLM, release 3.0.5): eight failed rounds, each recorded with
the rule it teaches, led to the uncapped defect and the eigenvalue bound. No
other AI system took part. The rank–trace framework is due to Alpöge and
Furman and is cited.

## How the result is checked

- The eigenvalue lemma, the stability lemma, the pinching step and the block
  accounting are proved by hand in the paper.
- The window inequality F₈ ≥ 13/3125 at μ₀ = 1/3200 is verified by branch and
  bound over a table of lower bounds for w = k² on cells of width 1/4000,
  computed in 128-bit ball arithmetic (python-flint/Arb). All bounds in the C
  search are computed with rounding toward minus infinity on nonnegative
  quantities. 10,039,560,518 nodes, VERIFIED; a second run at μ₀ = 1/2000 with
  an independent serial program also verified.
- The kernel values, the majorant inequality and the lattice eigenvalues are
  rechecked in ball and floating-point arithmetic.

## What is not claimed

The paper does not prove the Riemann hypothesis and does not bear on it: a
bound of this kind is insensitive to a set of zeros of density zero. The
argument uses the framework of the arXiv preprint of Alpöge and Furman, which
is not yet refereed.
