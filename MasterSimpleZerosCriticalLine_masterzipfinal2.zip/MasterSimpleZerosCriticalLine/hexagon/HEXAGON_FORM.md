# Hexagon submission fields

Title: More Than 67.31 Percent of the Zeta Zeros Are Simple and on the Critical Line

Abstract: We prove that more than 67.31 percent of the nontrivial zeros of the Riemann zeta function, counted with multiplicity, are simple and lie on the critical line, and that the method cannot reach 67.36 percent. The new ingredient is a sharp bound for the largest eigenvalue of the overlap matrix of well-separated zeros, which lets long blocks of zeros be used in full.

Primary subject: math.NT (Number Theory)
Cross-list subjects: none
Tags: Riemann zeta function, simple zeros, pair correlation, rank–trace inequality
MSC2020: 11M26 Nonreal zeros of ζ(s) and L(s, χ); Riemann and other hypotheses; 11M06 ζ(s) and L(s, χ); 15A42 Inequalities involving eigenvalues and eigenvectors; 42A05 Trigonometric polynomials, inequalities, extremal problems; 65G30 Interval and finite arithmetic

Contributor 1 (submitting): Deep Bhattacharjee; ORCID 0000-0003-0466-750X; affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; formerly, University of Calcutta, Senate House, 87/1 College Street, Kolkata 700073, West Bengal, India; itsdeep@live.com (second address d.bhattacharjee@erl-forschung.de)
Contributor 2: Ushashi Bhattacharya; ORCID 0009-0002-2254-3914; affiliation: Formerly, National Taiwan University, Taipei 106319, Taiwan; rai.bhattacharya.in@gmail.com

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: "All parts" only after both authors have read every proof; otherwise "Some parts, but not all".

Provenance statement: The proof, the text, the figures and the C, Python and shell programs were carried out by Deep Bhattacharjee with AI assistance (Claude, Anthropic) in the Claude Code environment. The search that led to the argument followed the learn-from-failure protocol of the BLLM engine Anaxia (creelie/eBLLM, release 3.0.5, doi:10.5281/zenodo.23469389). The rank–trace framework is due to L. Alpöge and Y. Furman (arXiv:2608.13637) and is credited and cited. The one computational step, an inequality for eight consecutive zeros, is verified in interval arithmetic (a kernel table in 128-bit ball arithmetic and a branch-and-bound search of 10,039,560,518 nodes in round-toward-minus-infinity arithmetic). The paper does not prove the Riemann hypothesis. Both authors approved the final version.

Tools used: Anthropic - Claude (Claude Code); C (GCC, OpenMP); Python (python-flint/Arb, NumPy, SciPy, Matplotlib); shell; TeX Live 2026.
arXiv identifier: none (not posted on arXiv).
Formalization: none (the verification code is at https://github.com/creelie/mh-phys/tree/main/verify).

Source files or ZIP: SimpleZerosCriticalLine_final2-tex.zip (main.tex and figures/ as PNG; compiles with pdflatex, no BibTeX pass). Do not upload the master zip here.
AI provenance files: AI_PROVENANCE_SimpleZerosCriticalLine.md
License: CC BY 4.0
Funding: none. Competing interests: none.
